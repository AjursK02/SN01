
import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';

const Hero = () => {
  // Featured banners for the Netflix-style carousel
  const featuredBanners = [
    {
      id: 1,
      title: "Celebrity Summer Collections",
      description: "Discover the hottest summer looks from your favorite celebrities",
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158",
      link: "/outfit/summer-collection"
    },
    {
      id: 2,
      title: "Red Carpet Inspirations",
      description: "Get inspired by the most elegant red carpet outfits",
      image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7",
      link: "/outfit/red-carpet"
    },
    {
      id: 3,
      title: "Street Style Favorites",
      description: "Casual and trendy street style looks for everyday fashion",
      image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5",
      link: "/outfit/street-style"
    }
  ];

  return (
    <div className="relative overflow-hidden">
      {/* Background with animated gradient */}
      <div 
        className="absolute inset-0 bg-gradient-to-br from-sanav/10 via-background to-background animate-gradient-slow" 
        aria-hidden="true"
      />
      
      <div className="container mx-auto px-4 sm:px-6 py-10 relative z-10">
        <div className="text-center max-w-4xl mx-auto">
          {/* Gender selection buttons moved to the top */}
          <div className="grid grid-cols-2 gap-4 max-w-2xl mx-auto mb-12 animate-fade-in">
            <Button size="xl" variant="glow" className="w-full group">
              <span>MEN</span>
            </Button>
            <Button size="xl" variant="outline3D" className="w-full">
              <span>WOMEN</span>
            </Button>
          </div>
          
          {/* Netflix-style scrolling banner */}
          <div className="mb-12 animate-fade-in animation-delay-200">
            <Carousel className="relative w-full">
              <CarouselContent>
                {featuredBanners.map((banner) => (
                  <CarouselItem key={banner.id}>
                    <Link to={banner.link} className="block">
                      <div className="relative h-[300px] md:h-[400px] rounded-xl overflow-hidden shadow-xl">
                        <img 
                          src={banner.image} 
                          alt={banner.title}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent flex flex-col justify-end p-6 text-left">
                          <h2 className="text-2xl md:text-3xl font-bold text-white mb-2">{banner.title}</h2>
                          <p className="text-sm md:text-base text-white/90 mb-4">{banner.description}</p>
                          <Button variant="glow" size="sm" className="w-fit">Explore Collection</Button>
                        </div>
                      </div>
                    </Link>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="absolute left-4 top-1/2" />
              <CarouselNext className="absolute right-4 top-1/2" />
            </Carousel>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in animation-delay-300">
            <Button asChild size="lg" variant="gradient" className="shadow-xl shadow-sanav/20">
              <Link to="/celebrities">
                Browse Celebrities
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="group">
              <Link to="/latest" className="flex items-center">
                Latest Outfits
                <ArrowRight size={16} className="ml-2 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
            </Button>
          </div>
          
          {/* Stats with animations */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mt-12 md:mt-16">
            {[
              { value: "1000+", label: "Outfits", delay: "400" },
              { value: "500+", label: "Celebrities", delay: "500" },
              { value: "300+", label: "Movies & Shows", delay: "600" },
              { value: "50+", label: "Brands", delay: "700" }
            ].map((stat, index) => (
              <div key={index} className={`p-5 rounded-lg bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm shadow-lg transform hover:-translate-y-1 transition-all duration-300 animate-fade-in animation-delay-${stat.delay}`}>
                <p className="text-2xl md:text-3xl font-bold text-gradient">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
