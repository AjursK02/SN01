
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, ChevronDown, Search, UserRound } from 'lucide-react';
import { Button } from './ui/button';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogDescription,
  DialogFooter
} from './ui/dialog';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { toast } from '@/hooks/use-toast';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [favoriteInfluencers, setFavoriteInfluencers] = useState('');
  const [favoriteCelebrities, setFavoriteCelebrities] = useState('');
  const [favoriteGenre, setFavoriteGenre] = useState('');

  const categories = [
    { name: "Celebrities", path: "/celebrities" },
    { name: "Movies", path: "/movies" },
    { name: "Influencers", path: "/influencers" },
    { name: "TV Shows", path: "/tv-shows" }
  ];

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Searching for:", searchQuery);
    // In a real app, we would redirect to search results page
  };

  const handleProfileSubmit = () => {
    // In a real app, we would save this information to a user profile
    console.log("Profile preferences:", { favoriteInfluencers, favoriteCelebrities, favoriteGenre });
    toast({
      title: "Preferences saved!",
      description: "Your style preferences have been updated."
    });
  };

  return (
    <nav className="sticky top-0 z-50 backdrop-blur-md bg-white/80 dark:bg-black/80 border-b border-border">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Link to="/" className="flex items-center">
              <span className="text-2xl font-bold text-gradient">SANAV</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {categories.map((category) => (
              <Link
                key={category.name}
                to={category.path}
                className="text-sm font-medium hover:text-sanav transition-colors"
              >
                {category.name}
              </Link>
            ))}
          </div>

          {/* Desktop Search and Profile */}
          <div className="hidden md:flex items-center space-x-4">
            <form onSubmit={handleSearch} className="relative">
              <input
                type="text"
                placeholder="Search outfits..."
                className="pl-3 pr-10 py-2 rounded-full text-sm border border-border focus:outline-none focus:ring-2 focus:ring-sanav focus:border-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button 
                type="submit" 
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-sanav"
              >
                <Search size={18} />
              </button>
            </form>
            
            {/* Profile Dialog */}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full hover:bg-secondary">
                  <UserRound size={20} />
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Your Style Profile</DialogTitle>
                  <DialogDescription>
                    Tell us about your style preferences to get personalized recommendations.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="influencers">Who are your favorite influencers?</Label>
                    <input
                      id="influencers"
                      placeholder="e.g., Emma Chamberlain, Hailey Bieber"
                      className="w-full rounded-md border border-border p-2"
                      value={favoriteInfluencers}
                      onChange={(e) => setFavoriteInfluencers(e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="celebrities">Who are your favorite celebrities?</Label>
                    <input
                      id="celebrities"
                      placeholder="e.g., Zendaya, Harry Styles"
                      className="w-full rounded-md border border-border p-2"
                      value={favoriteCelebrities}
                      onChange={(e) => setFavoriteCelebrities(e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>What's your favorite movie/TV genre?</Label>
                    <RadioGroup 
                      value={favoriteGenre} 
                      onValueChange={setFavoriteGenre}
                      className="grid grid-cols-2 gap-2"
                    >
                      {["Drama", "Action", "Comedy", "Sci-Fi", "Fantasy", "Romance"].map((genre) => (
                        <div key={genre} className="flex items-center space-x-2">
                          <RadioGroupItem value={genre} id={`genre-${genre}`} />
                          <Label htmlFor={`genre-${genre}`}>{genre}</Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleProfileSubmit}>Save preferences</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={toggleMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-foreground hover:text-sanav hover:bg-secondary focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-background border-t border-border">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {/* Mobile Search */}
            <form onSubmit={handleSearch} className="relative mb-4">
              <input
                type="text"
                placeholder="Search outfits..."
                className="w-full pl-3 pr-10 py-2 rounded-full text-sm border border-border focus:outline-none focus:ring-2 focus:ring-sanav focus:border-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button 
                type="submit" 
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-sanav"
              >
                <Search size={18} />
              </button>
            </form>

            {/* Mobile Navigation Links */}
            {categories.map((category) => (
              <Link
                key={category.name}
                to={category.path}
                className="block px-3 py-2 rounded-md text-base font-medium hover:text-sanav hover:bg-secondary"
                onClick={() => setIsMenuOpen(false)}
              >
                {category.name}
              </Link>
            ))}
            
            {/* Mobile Profile Link */}
            <Dialog>
              <DialogTrigger asChild>
                <Button 
                  variant="ghost" 
                  className="w-full flex justify-start px-3 py-2 rounded-md text-base font-medium hover:text-sanav hover:bg-secondary"
                >
                  <UserRound size={18} className="mr-2" />
                  Your Style Profile
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Your Style Profile</DialogTitle>
                  <DialogDescription>
                    Tell us about your style preferences to get personalized recommendations.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="mobile-influencers">Who are your favorite influencers?</Label>
                    <input
                      id="mobile-influencers"
                      placeholder="e.g., Emma Chamberlain, Hailey Bieber"
                      className="w-full rounded-md border border-border p-2"
                      value={favoriteInfluencers}
                      onChange={(e) => setFavoriteInfluencers(e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="mobile-celebrities">Who are your favorite celebrities?</Label>
                    <input
                      id="mobile-celebrities"
                      placeholder="e.g., Zendaya, Harry Styles"
                      className="w-full rounded-md border border-border p-2"
                      value={favoriteCelebrities}
                      onChange={(e) => setFavoriteCelebrities(e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>What's your favorite movie/TV genre?</Label>
                    <RadioGroup 
                      value={favoriteGenre} 
                      onValueChange={setFavoriteGenre}
                      className="grid grid-cols-2 gap-2"
                    >
                      {["Drama", "Action", "Comedy", "Sci-Fi", "Fantasy", "Romance"].map((genre) => (
                        <div key={genre} className="flex items-center space-x-2">
                          <RadioGroupItem value={genre} id={`mobile-genre-${genre}`} />
                          <Label htmlFor={`mobile-genre-${genre}`}>{genre}</Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleProfileSubmit} className="w-full">Save preferences</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
