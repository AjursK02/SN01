
import React from 'react';
import { Film, Star, Users, Tv } from 'lucide-react';
import CategoryCard from './CategoryCard';

const CategoryBrowser = () => {
  const categories = [
    {
      title: 'Celebrities',
      icon: <Star size={24} className="text-sanav" />,
      description: 'Find outfits worn by your favorite celebrities on red carpets, events, and everyday life.',
      path: '/celebrities',
    },
    {
      title: 'Movies',
      icon: <Film size={24} className="text-sanav" />,
      description: 'Discover iconic costumes and clothes from your favorite films and movie stars.',
      path: '/movies',
    },
    {
      title: 'Influencers',
      icon: <Users size={24} className="text-sanav" />,
      description: 'Shop the latest trends worn by top fashion influencers across social media.',
      path: '/influencers',
    },
    {
      title: 'TV Shows',
      icon: <Tv size={24} className="text-sanav" />,
      description: 'Get the looks of your favorite characters from popular television series.',
      path: '/tv-shows',
    },
  ];

  return (
    <section className="py-16 bg-secondary/50">
      <div className="container mx-auto px-4 sm:px-6">
        <h2 className="text-2xl font-bold text-center mb-10">Browse by Category</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category) => (
            <CategoryCard
              key={category.title}
              title={category.title}
              icon={category.icon}
              description={category.description}
              path={category.path}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryBrowser;
