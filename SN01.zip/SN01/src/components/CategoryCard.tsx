
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

interface CategoryCardProps {
  title: string;
  icon: React.ReactNode;
  description: string;
  path: string;
}

const CategoryCard = ({ title, icon, description, path }: CategoryCardProps) => {
  return (
    <Link to={path} className="block hover-scale">
      <div className="rounded-lg bg-white dark:bg-gray-800 shadow-sm hover:shadow-md border border-border p-6 h-full">
        <div className="flex items-center justify-between mb-4">
          <div className="bg-sanav/10 dark:bg-sanav/20 p-3 rounded-lg">
            {icon}
          </div>
          <ChevronRight size={16} className="text-sanav" />
        </div>
        <h3 className="text-lg font-medium mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </Link>
  );
};

export default CategoryCard;
